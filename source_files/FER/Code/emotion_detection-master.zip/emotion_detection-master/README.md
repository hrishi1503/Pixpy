# Emotion Detection

- Kaggle Dataset :- https://www.kaggle.com/c/challenges-in-representation-learning-facial-expression-recognition-challenge/data.

- Change the number of classes according to you.

- Do Experiment with different pre-trained models.

- Enjoy Deep Learning.

<img src="https://user-images.githubusercontent.com/49981970/66385330-f214bb80-e9dd-11e9-8388-07ad48d03dd2.jpg" width="500" height="500">
<img src="https://user-images.githubusercontent.com/49981970/66385331-f214bb80-e9dd-11e9-9cfc-70b6dbad0e55.jpg" width="500" height="500">
<img src="https://user-images.githubusercontent.com/49981970/66385333-f214bb80-e9dd-11e9-9105-a24309d362dc.jpg" width="500" height="500">
<img src="https://user-images.githubusercontent.com/49981970/66385313-ea551700-e9dd-11e9-847b-0765572833a6.jpg" width="500" height="500">

